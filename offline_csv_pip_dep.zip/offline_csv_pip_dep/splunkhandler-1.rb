require 'chef/handler'
require 'json'
# require 'net/http'
# require 'uri'
require 'time'

class ChefHandler < Chef::Handler
  def report
    # # Configure the HEC endpoint URL and authentication token
    # hec_url = URI.parse('https://10.54.105.39:8088/services/collector')
    # hec_token = '63dca5da-e86f-4afd-9302-038590172e45'
    execution_details, total_resources, updated_resources = resource_execution_details(run_status.all_resources)
    all_cookbooks_info = cookbook_run_status_list()
    all_updated_resources_list = detailed_cookbook_updater()
    file_name = Time.now.utc.strftime('%Y%m%d_%H%M%S') + '.json'
    directory_name = '/var/log/chef/splunk/report/'

    # Create the directory if it doesn't exist and set permissions to 777
    if !Dir.exist?(directory_name)
      FileUtils.mkdir_p(directory_name, mode: 0700)
    end

    # Delete any existing JSON files in the directory
    Dir.glob("#{directory_name}/*.json") do |file|
      File.delete(file)
    end
    # Build the event data to send to Splunk
    event_data = {
      host: node['hostname'],
      source: 'chef',
      sourcetype: 'chef:run',
      index: 'chef_historical_data',
      event: {
        status: run_status.success? ? 'success' : 'failure',
        start_time: run_status.start_time,
        end_time: run_status.end_time.utc,
        elapsed_time: run_status.elapsed_time,
        run_list: run_status.node.run_list.to_s,
        node_name: run_status.node.name,
        node_environment: run_status.node.environment,
        node_roles: run_status.node.run_list.roles,
        node_ipaddress: run_status.node['ipaddress'],
        node_tags: run_status.node.tags,
        node_attributes: run_status.node.attributes,
        exception: run_status.formatted_exception,
        backtrace: run_status.backtrace,
        recipes: run_status.node.run_list.recipes,
	      total_resources_count: total_resources,
	      updated_resources_count: updated_resources,
        cookbooks_info: all_cookbooks_info,
        updated_resources: all_updated_resources_list,
        resource_execution_details: execution_details
      }
    }

    # Write the event data to a JSON file in the directory
    File.open("#{directory_name}/#{file_name}", 'w') do |file|
      file.write(JSON.pretty_generate(event_data))
    end

    # Set permissions of the JSON file to 777
    FileUtils.chmod(0700, "#{directory_name}/#{file_name}")

    Chef::Log.info("Chef run data successfully dumped to JSON file: #{directory_name}/#{file_name}")
  end

  def detailed_cookbook_updater
    final = {}
    updated_resources.each do |res|
      res_details = "#{res.resource_name}['#{res.name}'] #{res.source_line}"
      final["#{res.cookbook_name}::#{res.recipe_name}"] = if final.key?("#{res.cookbook_name}::#{res.recipe_name}")
                                                              final["#{res.cookbook_name}::#{res.recipe_name}"] + [res_details]
                                                            else
                                                              [res_details]
                                                            end
      end
      final
    end

    def cookbook_run_status_list
      run_status_list = {}
      run_context.cookbook_collection.each do |cookbook_name, cookbook|
        cookbook_version = cookbook.version
        cookbook_run_status = if run_status.success?
                                'pass'
                              else
                                'fail'
                              end

        # If the cookbook run failed, extract the error message
        error_message = nil
        if cookbook_run_status == 'fail'
          error_message = run_status.exception.message
        end

        # Create a new dictionary with the cookbook information and add it to the list
        cookbook_info = {
          'cookbook_name' => cookbook_name,
          'cookbook_version' => cookbook_version.to_s,
          'run_status' => cookbook_run_status,
          'error_message' => error_message,
        }
        run_status_list[cookbook_name] = cookbook_info
      end
      run_status_list
    end

    def resource_execution_details(resources)
      execution_details = []
      updated_resources = 0
      total_resources = 0
      resources.each do |resource|
        details = {
          recipe: resource.cookbook_name.to_s   + '::' + resource.recipe_name,
          resource: resource.resource_name.to_s + '[' + resource.name.to_s + ']',
          action: resource.action.to_s,
          elapsed_time: resource.elapsed_time.to_s,
          updated: resource.updated?
        }
        execution_details << details
        total_resources += resource.action.size
        updated_resources += 1 if resource.updated?
      end
      return execution_details, total_resources, updated_resources
    end
end

